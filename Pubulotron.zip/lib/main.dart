import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

void main() {
  runApp(const PubulotronApp());
}

class PubulotronApp extends StatelessWidget {
  const PubulotronApp({super.key});

  @override
  Widget build(BuildContext context) {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF7545FF),
      brightness: Brightness.dark,
    );

    return MaterialApp(
      title: 'Pubulotron',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: colorScheme,
        scaffoldBackgroundColor: const Color(0xFF0F172A),
        cardTheme: const CardThemeData(elevation: 0, margin: EdgeInsets.zero),
      ),
      home: const PubulotronShell(),
    );
  }
}

class PubulotronShell extends StatefulWidget {
  const PubulotronShell({super.key});

  @override
  State<PubulotronShell> createState() => _PubulotronShellState();
}

class _PubulotronShellState extends State<PubulotronShell> {
  static const _storage = FlutterSecureStorage();
  static const List<String> _providers = [
    'OpenAI',
    'Claude',
    'Gemini',
    'Mistral',
  ];

  final TextEditingController _promptController = TextEditingController(
    text: 'Je suis réparateur informatique. Crée-moi une carte de visite futuriste avec un fond bleu électrique, mon téléphone et un QR code vers mon site internet.',
  );
  final TextEditingController _companyController = TextEditingController(
    text: 'TechCare Réparations',
  );
  final TextEditingController _sloganController = TextEditingController(
    text: 'Ton PC, notre obsession.',
  );
  final TextEditingController _phoneController = TextEditingController(
    text: '+33 6 12 34 56 78',
  );
  final TextEditingController _emailController = TextEditingController(
    text: 'contact@techcare-repair.fr',
  );
  final TextEditingController _websiteController = TextEditingController(
    text: 'techcare-repair.fr',
  );

  int _selectedIndex = 0;
  String _selectedProvider = _providers.first;
  String _apiKey = '';
  bool _darkMode = true;

  final List<DesignConcept> _concepts = [
    DesignConcept(
      title: 'Nexus Pixel',
      style: 'Futuriste',
      palette: 'Bleu électrique + violet',
      slogan: 'Réparer le futur, sans perdre le temps.',
      summary: 'Carte de visite à forte présence avec lignes de circuit et QR code premium.',
    ),
    DesignConcept(
      title: 'Signal Zero',
      style: 'Luxe techno',
      palette: 'Noir, cyan, orange',
      slogan: 'Votre PC mérite une seconde vie.',
      summary:
          'Affiche premium orientée diagnostics rapides et présence digitale.',
    ),
    DesignConcept(
      title: 'Cloud Break',
      style: 'Motion lab',
      palette: 'Violet, turquoise, blanc',
      slogan: 'Merci, les bugs, on les évite.',
      summary: 'Modèle dynamique pour flyer A5, parfait pour attirer les PME locales.',
    ),
    DesignConcept(
      title: 'Byte Pop',
      style: 'Pop digital',
      palette: 'Rose, bleu nuit, orange',
      slogan: 'Des réparations aussi rapides que fiables.',
      summary:
          'Composition moderne avec blocs lumineux et espace pour services.',
    ),
  ];

  final List<TemplateCard> _templates = [
    TemplateCard(
      title: 'Carte de visite',
      category: 'Informatique',
      accent: const Color(0xFF24C9C2),
      tag: 'A6',
    ),
    TemplateCard(
      title: 'Flyer salon',
      category: 'Événementiel',
      accent: const Color(0xFFFF6384),
      tag: 'A5',
    ),
    TemplateCard(
      title: 'Menu restaurant',
      category: 'Restauration',
      accent: const Color(0xFFFFAA45),
      tag: 'A4',
    ),
    TemplateCard(
      title: 'Affiche promo',
      category: 'Commerce',
      accent: const Color(0xFF7545FF),
      tag: 'A3',
    ),
  ];

  final List<ProjectCardData> _projects = [
    ProjectCardData(
      title: 'Flyer réparateur',
      status: 'À finaliser',
      updated: 'Il y a 2h',
      accent: const Color(0xFF7545FF),
    ),
    ProjectCardData(
      title: 'Pack fidélité',
      status: 'Validé',
      updated: 'Hier',
      accent: const Color(0xFF24C9C2),
    ),
    ProjectCardData(
      title: 'Menu café',
      status: 'Brouillon',
      updated: '3 jours',
      accent: const Color(0xFFFFAA45),
    ),
  ];

  final List<CreativeElement> _canvasElements = [
    CreativeElement(
      'Titre',
      0.15,
      0.15,
      230,
      60,
      const Color(0xFF7545FF),
      'text',
    ),
    CreativeElement(
      'Slogan',
      0.18,
      0.34,
      260,
      42,
      const Color(0xFF24C9C2),
      'text',
    ),
    CreativeElement(
      'Photo',
      0.53,
      0.18,
      180,
      180,
      const Color(0xFF17213B),
      'image',
    ),
    CreativeElement('CTA', 0.32, 0.68, 200, 52, const Color(0xFFFF6384), 'cta'),
    CreativeElement(
      'Contact',
      0.05,
      0.78,
      260,
      70,
      const Color(0xFFAA8CFF),
      'text',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _loadApiKey();
  }

  @override
  void dispose() {
    _promptController.dispose();
    _companyController.dispose();
    _sloganController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _websiteController.dispose();
    super.dispose();
  }

  Future<void> _loadApiKey() async {
    final key = await _storage.read(key: 'pubulotron_api_key');
    if (key != null && mounted) setState(() => _apiKey = key);
  }

  Future<void> _saveApiKey() async {
    await _storage.write(key: 'pubulotron_api_key', value: _apiKey);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Clé API sauvegardée en sécurité.')),
      );
    }
  }

  Future<void> _generateConcepts() async {
    setState(() {
      _concepts.clear();
      _concepts.addAll([
        DesignConcept(
          title: 'Astra Print',
          style: 'Tech premium',
          palette: 'Violet / cyan / blanc',
          slogan: 'L’expérience digitale qui monte en puissance.',
          summary: 'Composition orientée confiance, performance et conversion locale.',
        ),
        DesignConcept(
          title: 'Circuit Glow',
          style: 'Lab créatif',
          palette: 'Bleu électrique / rose',
          slogan: 'Nos solutions ne s’arrêtent jamais.',
          summary: 'Un design qui met en scène le savoir-faire technique et les résultats.',
        ),
        DesignConcept(
          title: 'Signal Studio',
          style: 'Minimal premium',
          palette: 'Noir / orange / argent',
          slogan: 'Prêt à relancer votre visibilité.',
          summary:
              'Structure élégante, idéale pour les services techniques et B2B.',
        ),
        DesignConcept(
          title: 'Rocket Fix',
          style: 'Pop performant',
          palette: 'Orange / violet / blanc',
          slogan: 'Solutions rapides, sans compromis.',
          summary: 'Grande lisibilité et impact sur les vitrines et cartes de visite.',
        ),
      ]);
    });
  }

  Future<void> _exportPdf() async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                'Pubulotron — Brief publicitaire',
                style: pw.TextStyle(
                  fontSize: 24,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 12),
              pw.Text('Entreprise: ${_companyController.text}'),
              pw.Text('Slogan: ${_sloganController.text}'),
              pw.Text('Téléphone: ${_phoneController.text}'),
              pw.Text('Email: ${_emailController.text}'),
              pw.Text('Site: ${_websiteController.text}'),
              pw.SizedBox(height: 16),
              pw.Text('Brief IA: ${_promptController.text}'),
              pw.SizedBox(height: 20),
              pw.Container(
                padding: const pw.EdgeInsets.all(12),
                decoration: pw.BoxDecoration(
                  borderRadius: const pw.BorderRadius.all(
                    pw.Radius.circular(8),
                  ),
                  color: PdfColors.purple100,
                ),
                child: pw.Text(
                  'Livrable prêt pour impression et diffusion numérique.',
                ),
              ),
            ],
          );
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  List<NavigationRailDestination> get _railDestinations => const [
    NavigationRailDestination(
      icon: Icon(Icons.add_box_outlined),
      label: Text('Nouvelle création'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.auto_awesome),
      label: Text('Création avec l\'IA'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.design_services_outlined),
      label: Text('Atelier graphique'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.grid_view_rounded),
      label: Text('Modèles'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.folder_copy_outlined),
      label: Text('Mes projets'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.collections_bookmark_outlined),
      label: Text('Pack publicitaire'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.picture_as_pdf_outlined),
      label: Text('Imprimerie PDF'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.business_center_outlined),
      label: Text('Mon activité'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.settings_applications_outlined),
      label: Text('Paramètres IA'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.help_center_outlined),
      label: Text('Mode d\'emploi'),
    ),
  ];

  Widget _buildDestinationBody() {
    final screens = <Widget>[
      _buildNewCreationScreen(),
      _buildAiCreationScreen(),
      _buildStudioScreen(),
      _buildTemplateScreen(),
      _buildProjectsScreen(),
      _buildPackScreen(),
      _buildPrintScreen(),
      _buildIdentityScreen(),
      _buildAiSettingsScreen(),
      _buildHelpScreen(),
    ];
    return screens[_selectedIndex];
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.sizeOf(context).width >= 760;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF101828),
        foregroundColor: Colors.white,
        centerTitle: false,
        title: const Row(
          children: [
            Icon(Icons.smart_toy_rounded, color: Color(0xFF24C9C2)),
            SizedBox(width: 12),
            Text('Pubulotron'),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => setState(() => _darkMode = !_darkMode),
            icon: Icon(
              _darkMode ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
            ),
          ),
        ],
      ),
      body: isWide
          ? Row(
              children: [
                NavigationRail(
                  selectedIndex: _selectedIndex,
                  onDestinationSelected: (index) =>
                      setState(() => _selectedIndex = index),
                  extended: true,
                  backgroundColor: const Color(0xFF111827),
                  destinations: _railDestinations,
                ),
                const VerticalDivider(width: 1),
                Expanded(child: _buildDestinationBody()),
              ],
            )
          : SafeArea(
              child: Column(
                children: [
                  SizedBox(
                    height: 80,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      itemCount: _railDestinations.length,
                      itemBuilder: (context, index) {
                        final item = _railDestinations[index];
                        return GestureDetector(
                          onTap: () => setState(() => _selectedIndex = index),
                          child: Container(
                            width: 140,
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            decoration: BoxDecoration(
                              color: index == _selectedIndex
                                  ? const Color(0xFF7545FF)
                                        .withValues(alpha: 0.16)
                                  : const Color(0xFF1F2937),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Row(
                              children: [
                                item.icon,
                                const SizedBox(width: 8),
                                Flexible(child: item.label),
                              ],
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (context, index) => const SizedBox(width: 8),
                    ),
                  ),
                  Expanded(child: _buildDestinationBody()),
                ],
              ),
            ),
    );
  }

  Widget _buildDashboardCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return SizedBox(
      width: 180,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF111827),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withValues(alpha: 0.20)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [color, color.withValues(alpha: 0.65)],
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewCreationScreen() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Nouvelle création',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'Démarrez depuis une idée, un besoin marketing ou un brief métier.',
            style: Theme.of(context).textTheme.bodyLarge
                ?.copyWith(color: Colors.white70),
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _buildDashboardCard(
                title: 'Projets actifs',
                value: '18',
                icon: Icons.folder_special_outlined,
                color: const Color(0xFF7545FF),
              ),
              _buildDashboardCard(
                title: 'Concepts IA',
                value: '64',
                icon: Icons.auto_awesome,
                color: const Color(0xFF24C9C2),
              ),
              _buildDashboardCard(
                title: 'Impressions',
                value: '11',
                icon: Icons.print_outlined,
                color: const Color(0xFFFFAA45),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF111827),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Brief créatif',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _promptController,
                  minLines: 4,
                  maxLines: 6,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: const Color(0xFF1B2436),
                    hintText: 'Décrivez l’activité, le format, les couleurs et les éléments à inclure…',
                    hintStyle: const TextStyle(color: Colors.white38),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    ElevatedButton.icon(
                      onPressed: () => setState(() => _selectedIndex = 1),
                      icon: const Icon(Icons.auto_awesome),
                      label: const Text('Créer 4 concepts'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => setState(() => _selectedIndex = 2),
                      icon: const Icon(Icons.design_services_outlined),
                      label: const Text('Ouvrir l’atelier'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAiCreationScreen() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Création avec l’IA',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'Les concepts sont générés à partir d’un prompt, puis adaptés à votre identité de marque.',
            style: Theme.of(context).textTheme.bodyLarge
                ?.copyWith(color: Colors.white70),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: _concepts.map((concept) {
              return Container(
                width: 280,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF111827), Color(0xFF1F2937)],
                  ),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          concept.title,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const Spacer(),
                        Chip(label: Text(concept.style)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      concept.summary,
                      style: const TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Palette : ${concept.palette}',
                      style: const TextStyle(
                        color: Color(0xFF24C9C2),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Slogan : ${concept.slogan}',
                      style: const TextStyle(
                        color: Color(0xFFFFAA45),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        FilledButton.tonal(
                          onPressed: () {},
                          child: const Text('Choisir'),
                        ),
                        const SizedBox(width: 8),
                        TextButton(
                          onPressed: () => setState(() => _selectedIndex = 2),
                          child: const Text('Éditer'),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _generateConcepts,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Régénérer les concepts'),
          ),
        ],
      ),
    );
  }

  Widget _buildStudioScreen() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Atelier graphique',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'Éditez les éléments indépendamment, alignez-les et préparez votre visuel final.',
            style: Theme.of(context).textTheme.bodyLarge
                ?.copyWith(color: Colors.white70),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 8,
            children: [
              FilledButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.title),
                label: const Text('Texte'),
              ),
              FilledButton.tonal(
                onPressed: () {},
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.image),
                    SizedBox(width: 8),
                    Text('Photo'),
                  ],
                ),
              ),
              FilledButton.tonal(
                onPressed: () {},
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.category),
                    SizedBox(width: 8),
                    Text('Forme'),
                  ],
                ),
              ),
              FilledButton.tonal(
                onPressed: () {},
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.grid_3x3),
                    SizedBox(width: 8),
                    Text('Grille'),
                  ],
                ),
              ),
              FilledButton.tonal(
                onPressed: () {},
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.undo),
                    SizedBox(width: 8),
                    Text('Annuler'),
                  ],
                ),
              ),
              FilledButton.tonal(
                onPressed: () {},
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.redo),
                    SizedBox(width: 8),
                    Text('Rétablir'),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            height: 520,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: const Color(0xFF101828),
              borderRadius: BorderRadius.circular(26),
              border: Border.all(
                color: const Color(0xFF7545FF).withValues(alpha: 0.25),
              ),
            ),
            child: Stack(
              children: _canvasElements.asMap().entries.map((entry) {
                final index = entry.key;
                final element = entry.value;
                return Positioned(
                  left: element.x * 320,
                  top: element.y * 360,
                  width: element.width.toDouble(),
                  height: element.height.toDouble(),
                  child: GestureDetector(
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Élément sélectionné : ${element.name}',
                          ),
                        ),
                      );
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      padding: const EdgeInsets.all(10),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: element.color,
                        borderRadius: BorderRadius.circular(
                          element.kind == 'image' ? 18 : 12,
                        ),
                        border: index == 0
                            ? Border.all(color: Colors.white, width: 2)
                            : null,
                      ),
                      child: element.kind == 'image'
                          ? const Icon(
                              Icons.image_outlined,
                              color: Colors.white,
                              size: 48,
                            )
                          : Text(
                              element.name,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTemplateScreen() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Bibliothèque de modèles',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'Partir d’un modèle personnalisable ou d’une page blanche.',
            style: Theme.of(context).textTheme.bodyLarge
                ?.copyWith(color: Colors.white70),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            children: _templates.map((template) {
              return Container(
                width: 220,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF111827),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                template.accent,
                                template.accent.withValues(alpha: 0.6),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        const Spacer(),
                        Chip(label: Text(template.tag)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      template.title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      template.category,
                      style: const TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 14),
                    FilledButton.tonal(
                      onPressed: () {},
                      child: const Text('Utiliser ce modèle'),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildProjectsScreen() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Mes projets',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 20),
          ..._projects.map((project) {
            return Container(
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Row(
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          project.accent,
                          project.accent.withValues(alpha: 0.6),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: const Icon(
                      Icons.design_services,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          project.title,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          project.updated,
                          style: const TextStyle(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                  Chip(label: Text(project.status)),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildPackScreen() {
    final offers = [
      'Carte de visite premium',
      'Flyer A5 promo',
      'Affiche évènement',
      'Pack réseaux sociaux',
      'Mini dépliant',
      'Carte fidélité',
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Pack publicitaire',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'Activez une campagne prête à l’emploi: supports, visuels, textes et versions web.',
            style: Theme.of(context).textTheme.bodyLarge
                ?.copyWith(color: Colors.white70),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: offers.map((offer) {
              return ChoiceChip(
                label: Text(offer),
                selected: offer == 'Flyer A5 promo',
                onSelected: (_) {},
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildPrintScreen() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Imprimerie PDF',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'Prévisualisation du document, réglages et export professionnel.',
            style: Theme.of(context).textTheme.bodyLarge
                ?.copyWith(color: Colors.white70),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: const Color(0xFF111827),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Prévisualisation',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF7545FF), Color(0xFF24C9C2)],
                    ),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _companyController.text,
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _sloganController.text,
                        style: const TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          const Icon(Icons.phone, color: Colors.white),
                          const SizedBox(width: 8),
                          Text(
                            _phoneController.text,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: _exportPdf,
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                  label: const Text('Exporter PDF'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIdentityScreen() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Mon activité professionnelle',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 20),
          Card(
            color: const Color(0xFF111827),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  TextField(
                    controller: _companyController,
                    decoration: const InputDecoration(
                      labelText: 'Nom de l’activité',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _sloganController,
                    decoration: const InputDecoration(labelText: 'Slogan'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _phoneController,
                    decoration: const InputDecoration(labelText: 'Téléphone'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _emailController,
                    decoration: const InputDecoration(labelText: 'Email'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _websiteController,
                    decoration: const InputDecoration(
                      labelText: 'Site internet',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAiSettingsScreen() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Paramètres IA',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 20),
          Card(
            color: const Color(0xFF111827),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Fournisseur AI',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    initialValue: _selectedProvider,
                    dropdownColor: const Color(0xFF111827),
                    items: _providers
                        .map(
                          (provider) => DropdownMenuItem(
                            value: provider,
                            child: Text(provider),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => _selectedProvider = value);
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Clé API',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    obscureText: true,
                    onChanged: (value) => _apiKey = value,
                    decoration: const InputDecoration(hintText: 'sk-…'),
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: _saveApiKey,
                    icon: const Icon(Icons.lock_outline),
                    label: const Text('Sauvegarder la clé'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHelpScreen() {
    final steps = [
      '1. Rédigez un brief clair avec le format, les couleurs et les objectifs.',
      '2. Générez 4 concepts IA et choisissez le meilleur design.',
      '3. Ajustez les éléments directement dans l’atelier graphique.',
      '4. Exportez vers PDF, partagez sur les réseaux ou imprimez votre visuel.',
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Mode d’emploi',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 20),
          ...steps.map(
            (step) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF111827),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(step, style: const TextStyle(fontSize: 16)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class DesignConcept {
  DesignConcept({
    required this.title,
    required this.style,
    required this.palette,
    required this.slogan,
    required this.summary,
  });

  final String title;
  final String style;
  final String palette;
  final String slogan;
  final String summary;
}

class TemplateCard {
  TemplateCard({
    required this.title,
    required this.category,
    required this.accent,
    required this.tag,
  });

  final String title;
  final String category;
  final Color accent;
  final String tag;
}

class ProjectCardData {
  ProjectCardData({
    required this.title,
    required this.status,
    required this.updated,
    required this.accent,
  });

  final String title;
  final String status;
  final String updated;
  final Color accent;
}

class CreativeElement {
  CreativeElement(
    this.name,
    this.x,
    this.y,
    this.width,
    this.height,
    this.color,
    this.kind,
  );

  final String name;
  final double x;
  final double y;
  final double width;
  final double height;
  final Color color;
  final String kind;
}
